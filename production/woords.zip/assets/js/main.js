"use strict";

document.addEventListener("DOMContentLoaded", function () {

    function addNotProseClass() {
        document.querySelectorAll(".kg-card").forEach(el => {
            el.classList.add("not-prose");
        });
    }

    function responsiveTable() {
        document.querySelectorAll('.post-content > table').forEach(table => {
            const wrapper = document.createElement('div');
            wrapper.className = 'trex-table';
            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
        });
    }

    function initLightBox() {
        lightbox(
            '.kg-image-card > .kg-image[width][height], .kg-gallery-image > img'
        );
    }

    function load_more_posts() {
        if(document.getElementById('trex_blog')) {
            const nextLink = document.querySelector('.pagination .older-posts');
            if (!nextLink) {
                return;
            }
            
            let elem = document.getElementById('trex_blog');
            let infScroll = new InfiniteScroll(elem, {
                append: '.trex_post',
                button: '.infinite-scroll-button',
                debug: false,
                hideNav: '.pagination',
                history: false,
                path: '.pagination .older-posts',
                scrollThreshold: false,
                status: '.infinite-scroll-status',
            });

            infScroll.on( 'append', function( body, path, items, response ) {
                setTimeout(() => {
                    trex_tooltip();
                    assignTagClasses();
                }, 100);
            });
        }
    }

    function trex_tooltip() {
        tippy('.trex-tipy-tag', {
            content(reference) {
                const id = reference.getAttribute('data-template');
                const template = document.getElementById(id);
                if (!template) return '';
                const content = template.innerHTML;
                return content.replace(/>\s*([a-z])/i, (match, letter) => {
                    return match.replace(letter, letter.toUpperCase());
                });
            },
            allowHTML: true,
        });

        tippy('[data-tippy-content]');
    }

    function copy_link() {
        const btn = document.getElementById('copy-link-btn');
        if(btn) {
            const instance = tippy('#copy-link-btn', {
                trigger: 'manual',
            });
            document.getElementById('copy-link-btn').addEventListener('click', () => {
                const fullUrl = window.location.href;
                navigator.clipboard.writeText(fullUrl).then(() => {
                    instance[0].setContent('Link copied!');
                    instance[0].show();
                    setTimeout(() => {
                        instance[0].hide();
                    }, 2000);
                });
            });
        }
    }

    function fixCommentsCtaColors() {
        const isDark = document.documentElement.classList.contains('dark');
        if (!isDark) return;

        const css =
            `section[data-testid="cta-box"] h1,` +
            `section[data-testid="cta-box"] h2,` +
            `section[data-testid="cta-box"] h3{color:#ffffff!important}` +
            `section[data-testid="cta-box"] p,` +
            `section[data-testid="cta-box"] span{color:rgba(255,255,255,0.8)!important}`;

        const ghostEl = document.querySelector('ghost-comments');
        const root = ghostEl && ghostEl.shadowRoot;
        if (!root) return;

        let styleEl = root.getElementById('woords-cta-fix');
        if (!styleEl) {
            styleEl = document.createElement('style');
            styleEl.id = 'woords-cta-fix';
            root.appendChild(styleEl);
        }
        styleEl.textContent = css;
    }

    function watchGhostStyles() {
        // Re-apply when Ghost injects its own styles into <head>
        const headObserver = new MutationObserver(function(mutations) {
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1 && node.tagName === 'STYLE' && node.id !== 'woords-cta-fix') {
                        fixCommentsCtaColors();
                    }
                }
            }
        });
        headObserver.observe(document.head, { childList: true });

        // Also watch for ghost-comments element being added to the DOM
        const bodyObserver = new MutationObserver(function(mutations) {
            for (const mutation of mutations) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1 && node.tagName === 'GHOST-COMMENTS') {
                        // Shadow root may not be populated yet; defer slightly
                        setTimeout(fixCommentsCtaColors, 300);
                        bodyObserver.disconnect();
                    }
                }
            }
        });
        bodyObserver.observe(document.body, { childList: true, subtree: true });
    }

    function switchModeFn() {
        if (localStorage.theme !== 'light') {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
        fixCommentsCtaColors();
    }

    function watchMode() {
        try {
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', switchModeFn);
        } catch (e) {
            // Safari fallback
            window.matchMedia('(prefers-color-scheme: dark)').addListener(switchModeFn);
        }
    }

    function bindSwitchModeBtn() {
        const btn = document.querySelector('.switch-mode');
        if (btn) {
            btn.addEventListener('click', function () {
                localStorage.theme = (localStorage.theme !== 'light') ? 'light' : 'dark';
                switchModeFn();
            });
        }
    }

    function trending_tags() {
        var c = document.getElementById("trending-tags");
        if (!c) return;
        const trending_tags = new Splide('#trending-tags', {
            type: 'loop',
            perPage: 4,
            pagination: false,
            arrows: false,
            perMove: 1,
            gap: 16,
            breakpoints: {
                1024: {
                    perPage: 3,
                },
                834: {
                    perPage: 2,
                },
                640: {
                    perPage: 1,
                }
            }
        }).mount();

        const prevBtn = document.getElementById("move-left");
        const nextBtn = document.getElementById("move-right");

        if (prevBtn) {
            prevBtn.addEventListener("click", () => trending_tags.go("<"));
        }
        if (nextBtn) {
            nextBtn.addEventListener("click", () => trending_tags.go(">"));
        }
    }

    function tag_section() {
        var c = document.getElementById("tag-section");
        if (!c) return;
        const trending_tags = new Splide('#tag-section', {
            type: 'loop',
            perPage: 4,
            pagination: false,
            arrows: false,
            perMove: 1,
            gap: 16,
            breakpoints: {
                1024: {
                    perPage: 3,
                },
                834: {
                    perPage: 2,
                },
                640: {
                    perPage: 1,
                }
            }
        }).mount();

        const prevBtn = document.getElementById("move-left-two");
        const nextBtn = document.getElementById("move-right-two");

        if (prevBtn) {
            prevBtn.addEventListener("click", () => trending_tags.go("<"));
        }
        if (nextBtn) {
            nextBtn.addEventListener("click", () => trending_tags.go(">"));
        }
    }

    function createResponsiveNavigation() {
        const navContainer = document.getElementById('main-nav');
        if (!navContainer) return null;

        const maxLinks = parseInt(navContainer.getAttribute('data-number-links'), 10);
        if (isNaN(maxLinks)) return null;

        const moreLabel = navContainer.getAttribute('data-label') || "More";
        const navList = navContainer.querySelector('.nav');
        if (!navList) return null;

        const allLinks = Array.from(navList.children || []);
        if (allLinks.length === 0) return null;

        // If we have more links than the maximum allowed
        if (allLinks.length > maxLinks) {
            // Get the links that should be moved to dropdown
            const linksToMove = allLinks.slice(maxLinks);
            if (linksToMove.length === 0) return null;

            // Remove the extra links from the main navigation
            linksToMove.forEach(link => {
                if (link && navList.contains(link)) {
                    navList.removeChild(link);
                }
            });

            // Create the "More" dropdown
            const moreDropdown = document.createElement('li');
            moreDropdown.className = 'nav-more relative';
            moreDropdown.innerHTML = `
                <button class="more-toggle flex items-center" type="button">
                    <span>${moreLabel}</span>
                    <span>
                        <svg class="w-4 h-4 ml-1 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </span>
                </button>
                <ul class="dropdown-menu trex-dropdown opacity-0 invisible"></ul>
            `;

            const dropdownMenu = moreDropdown.querySelector('.dropdown-menu');
            if (!dropdownMenu) return null;

            // Add the moved links to the dropdown
            linksToMove.forEach(link => {
                if (!link) return;

                const dropdownItem = document.createElement('li');
                dropdownItem.className = 'trex-sublink-wrapper';

                if (link.className) {
                    dropdownItem.className += ' ' + link.className;
                }
                if (link.id) {
                    dropdownItem.id = link.id;
                }

                const originalLink = link.querySelector('a');
                if (!originalLink) return;

                const newLink = originalLink.cloneNode(true);
                newLink.className = 'trex-sublink';

                if (originalLink.className) {
                    newLink.className += ' ' + originalLink.className;
                }
                if (originalLink.id) {
                    newLink.id = originalLink.id;
                }

                dropdownItem.appendChild(newLink);
                dropdownMenu.appendChild(dropdownItem);
            });

            // Add the dropdown to the navigation
            navList.appendChild(moreDropdown);

            // Dropdown toggle elements
            const toggleButton = moreDropdown.querySelector('.more-toggle');
            const dropdownMenuElement = moreDropdown.querySelector('.dropdown-menu');
            const chevronIcon = toggleButton ? toggleButton.querySelector('svg') : null;

            if (!toggleButton || !dropdownMenuElement) return null;

            let isOpen = false;

            function toggleDropdown(forceClose = false) {
                isOpen = forceClose ? false : !isOpen;

                if (isOpen) {
                    dropdownMenuElement.classList.remove('opacity-0', 'invisible', 'scale-95');
                    dropdownMenuElement.classList.add('opacity-100', 'visible', 'scale-100');
                    if (chevronIcon) chevronIcon.style.transform = 'rotate(180deg)';
                } else {
                    dropdownMenuElement.classList.add('opacity-0', 'invisible', 'scale-95');
                    dropdownMenuElement.classList.remove('opacity-100', 'visible', 'scale-100');
                    if (chevronIcon) chevronIcon.style.transform = 'rotate(0deg)';
                }
            }

            // Toggle dropdown on button click
            toggleButton.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                toggleDropdown();
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!moreDropdown.contains(e.target) && isOpen) {
                    toggleDropdown(true);
                }
            });

            // Close dropdown on escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && isOpen) {
                    toggleDropdown(true);
                }
            });

            // Handle keyboard navigation
            const dropdownLinks = dropdownMenuElement.querySelectorAll('a');
            toggleButton.addEventListener('keydown', function(e) {
                if ((e.key === 'Enter' || e.key === ' ') && dropdownLinks.length > 0) {
                    e.preventDefault();
                    toggleDropdown();
                    if (isOpen) dropdownLinks[0].focus();
                } else if (e.key === 'ArrowDown' && isOpen && dropdownLinks.length > 0) {
                    e.preventDefault();
                    dropdownLinks[0].focus();
                }
            });

            // Handle arrow key navigation within dropdown
            dropdownLinks.forEach((link, index) => {
                link.addEventListener('keydown', function(e) {
                    if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        const nextIndex = (index + 1) % dropdownLinks.length;
                        dropdownLinks[nextIndex].focus();
                    } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        const prevIndex = index === 0 ? dropdownLinks.length - 1 : index - 1;
                        dropdownLinks[prevIndex].focus();
                    } else if (e.key === 'Escape') {
                        e.preventDefault();
                        toggleDropdown(true);
                        toggleButton.focus();
                    }
                });
            });
        }

        // Always reveal navContainer if it exists
        navContainer.classList.remove("hidden");
        return true;
    }

    function assignTagClasses() {
        document.querySelectorAll('.post-tags').forEach(function(container) {
            var links = Array.from(container.querySelectorAll('a'));
            var ranks = ['primary', 'secondary', 'tertiary'];
            links.forEach(function(link, i) {
                if (i < ranks.length) link.classList.add(ranks[i]);
            });
        });
    }

    function initFooterShare() {
        const form = document.getElementById('footer-share-form');
        if (!form) return;
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('share-email-input').value.trim();
            if (!email) return;
            const subject = encodeURIComponent('Thought you might like this');
            const body = encodeURIComponent(
                'Hey,\n\n' +
                'This site/article sounds cool and informative — I thought you might be interested.\n\n' +
                window.location.href +
                '\n\nEnjoy!'
            );
            window.open('mailto:' + email + '?subject=' + subject + '&body=' + body);
            form.reset();
        });
    }

    window.membershipClick = function(radio) {
        if (radio.value === "month") {
            document.getElementById("trex_membership").classList.remove("trex_plan_yearly_price");
            document.getElementById("trex_membership").classList.add("trex_plan_monthly_price");
        } else {
            document.getElementById("trex_membership").classList.remove("trex_plan_monthly_price");
            document.getElementById("trex_membership").classList.add("trex_plan_yearly_price");
        }
    };

    function defaultCheckMembership() {
        const yearlyRadio = document.getElementById("trex_plan_year");
        if(yearlyRadio) {
            yearlyRadio.checked = true;
            membershipClick(yearlyRadio);
        }
    }

    function taxonomy_name() {
        let names = document.getElementsByClassName('trex_taxonomy_name');
        [].forEach.call(names, function (el) {
            const fullName = el.innerText.trim();
            el.setAttribute('title', fullName);
            el.setAttribute('aria-label', fullName);
            el.innerText = getFirstLetters(fullName);
            el.classList.remove("hidden");
            el.classList.add("flex");
        });
    }

    function getFirstLetters(str) {
        const firstLetters = str
        .split(' ')
        .map(word => word[0])
        .join('');
    
        return firstLetters;
    }

    taxonomy_name();
    defaultCheckMembership();
    assignTagClasses();
    initFooterShare();
    load_more_posts();
    responsiveTable();
    addNotProseClass();
    initLightBox();
    copy_link();
    trex_tooltip();
    switchModeFn();
    watchMode();
    bindSwitchModeBtn();
    trending_tags();
    tag_section();
    createResponsiveNavigation();
    fixCommentsCtaColors();
    watchGhostStyles();
});
